<?php
 include_once('bakeryconn.php');
 $query_string='
  CREATE TABLE Eppy(
   employee_number int(10) PRIMARY KEY,
  name varchar(10),
  surname varchar(10),
  physical_address varchar(40),
  email_address varchar(20),
  telephone int(10),
  Date_of_Birth int(20),
  Gender varchar(10),
  position varchar(10),
  branch varchar(10),
  employment_status varchar(10),
  city varchar(10),
  country varchar(10),
   Date varchar(10),
  username varchar(40),
  password varchar(9) 
     
  )
   ';

   if($bakery_conn->query($query_string)){
	   
	   echo "You have created your table<br>";
   }
?>

<!doctype html>
<html>
<body>
</body>
</html>