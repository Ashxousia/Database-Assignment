<?php
include_once('bakeryconn.php');
if(isset($_POST['username'])&&isset($_POST['password'])){
	
$username= $_POST['username'];
$password = $_POST['password'];

  if(!empty($username)&&!empty($password)){
	$query_string="SELECT * FROM eppy where username='$username' and password ='$password' ";
 $resultSet=$bakery_conn->query($query_string);
 $numberOfRows=$resultSet->num_rows;
 for($count=0;$count<$numberOfRows;$count++){
	 $bakeryObject=$resultSet->fetch_object();
	 echo $bakeryObject->name.", ".$bakeryObject->password."<br>";
	  $_SESSION['Sweetenize ur Tounge with Eppy......'] = $index;
 header("Location: baker_index.php"); // Redirect user to index.php
 
	}

  }else{
	  echo'fill in the missing fields'.'<br>';
  } 
}

?>


<html>
<body>
<form action="bakerylogin.php" method="POST">
Username: <input type="text" name="username"><br>
Password: <input type="password" name="password"><br>
<input type="submit" value="login">
</form>

</body>
</html>