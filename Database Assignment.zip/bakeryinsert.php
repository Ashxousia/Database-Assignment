<!DOCTYPE html>
<html>
<head>
</head>
<body>

	<?php
	$fname=$_POST['Name'];
	$sname=$_POST['Surname'];
	$address=$_POST['Physical_Address'];
	$email=$_POST['Email_Address'];
	$telephone=$_POST['Telephone'];
	$dob=$_POST['Date_of_Birth'];
	$gender=$_POST['Choose_Gender'];
	$position=$_POST['Position'];
	$branch=$_POST['Branch'];
	$status=$_POST['Employment_Status'];
	$city=$_POST['City'];
	$country=$_POST['Select_Country_Please'];
	$employee=$_POST['Employee_Number'];
	$date=$_POST['Date'];
	$username=$_POST['username'];
	$password=$_POST['password'];
	
	
	
	echo "Your first name is $fname<br> ";
	echo "Your Surname name is $sname<br> ";
	echo "Your address is $address <br>";
	echo "Your email is $email<br> ";
	echo "Your telephone is $telephone<br> ";
	echo "Your Date of Birth is $dob <br>";
	echo "Your gender is $gender <br>";
	echo "Your position is $position<br> ";
	echo "Your branch is $branch<br> ";
	echo "Your employment status is $status<br> ";
	echo "Your city is $city<br> ";
	echo "Your country is $country <br>";
	echo "Your employee number is $employee<br> ";
	echo "Your date is $date <br>";
	echo "Your username is $username <br>";
	echo "Your password is $password <br>";
	
	
 include_once('bakeryconn.php');
 $query_string="
 INSERT INTO Eppy
 Values ('$employee','$fname','$sname','$address','$email','$telephone','$dob','$gender','$position','$branch','$status','$city','$country','$date','$username','$password')
   ";

   if($bakery_conn->query($query_string)){
	   
	   echo "Yeaahh Data has been inserted sharp sharp!!";
   }
?>

<!doctype html>
<html>
<body>
</body>
</html>

	
	
