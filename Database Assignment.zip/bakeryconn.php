<?php
$bakery_conn=new mysqli('localhost','bakeryuser','bakery','bakerydb');
  if($bakery_conn->connect_errno){
	  
	  echo "Error".$bakery_conn->connect_errno." has occured";
	  
  }else{
	  
	
  }
	
?>

